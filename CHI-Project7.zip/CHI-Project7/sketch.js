let classifier;
  // Model URL
  let imageModelURL = './my_model/';
  
  // Video
  let video;
  let flippedVideo;
  let sky;
  let hw;
  let tb;
  let img_x;
  let img_y;
  let inputElement;
  let userImage;
  let toll = 0.0;
  let tollB;
  let tollF;
  // To store the classification
  let label = "";

  // Load the model first
  function preload() {
    sky = loadImage('assets/sky.jpeg');
    hw = loadImage('assets/highway.png');
    classifier = ml5.imageClassifier(imageModelURL + 'model.json');
    tollB = loadImage('assets/toll booth back.png');
    tollF = loadImage('assets/toll booth front.png');
  }

  function setup() {
    createCanvas(1120, 750);
    img_x = 0;
    img_y = 470;
    // Create the video
    // video = createCapture(VIDEO);
    // video.size(320, 240);
    // video.hide();

    // flippedVideo = ml5.flipImage(video);
    // Start classifying
    // classifyVideo();
    image(sky, 0,0);
    hw.resize((hw.width * .75), (hw.height * .75));
    image(hw, 0, 200);
    inputElement = createFileInput(handleFile);
  }

  function draw() {
    if (keyIsDown(LEFT_ARROW)) {
      img_x -= 5;
    }

    if (keyIsDown(RIGHT_ARROW)) {
      img_x += 5;
    }

    if (keyIsDown(UP_ARROW)) {
      img_y -= 5;
      if(img_y < 470){
        img_y = 470;
      }
    }

    if (keyIsDown(DOWN_ARROW)) {
      img_y += 5;
      if(img_y > 660){
        img_y = 660;
      }
    }
    console.log(img_x, img_y);


    image(sky, 0,0);
    image(hw, 0, 200);

    image(tollB, 380, 250);
    if (userImage != null) {
      image(userImage, img_x, img_y, 240, 140);
      inputElement.hide();
      fill(0);
      textSize(20);
      textAlign(CENTER);
      textStyle(BOLD);
      text("Drive your car using the arrow keys", 545, 200);
    }else{
      drawInput();
    }
    image(tollF, 440, 480);

    // Draw the label
    if(label != ""){
      drawOutput();
    }

    if(img_x >= 740){
      classifyVideo();
    }    
    fill(color(0, 130, 0, 255));
    var signbg = rect(420, 20, 250, 130, 20);
    fill(255);
    textSize(20);
    textAlign(CENTER);
    text("Sedans: $2", 545, 65);
    text("Mini-Vans: $4", 545, 90);
    text("Pickup Trucks: $6", 545, 115);
  }
  

  // Get a prediction for the current video frame
  function classifyVideo() {
    // flippedVideo = ml5.flipImage(video)
    // classifier.classify(flippedVideo, gotResult);
    // flippedVideo.remove();
    if (userImage != null) {
      classifier.classify(userImage, gotResult);
      userImage = null;
      inputElement.show();
    }

  }

  // When we get a result
  function gotResult(error, results) {
    // If there is an error
    if (error) {
      console.error(error);
      return;
    }
    // The results are in an array ordered by confidence.
    // console.log(results[0]);
    label = results[0].label;
    // Classifiy again!
    classifyVideo();
  }

  function handleFile(file) {
    print(file);
  
    if (file.type === 'image') {
      img_x = 0;
      img_y = 470;
      userImage = createImg(file.data, '');
      userImage.hide();
      label = "";
    } else {
      userImage = null;
    }
  }

  function drawInput(){
    fill(color(255, 255, 255, 70));
    var bg = rect(30, 20, 250, 130, 20);
    fill(255);
    textSize(18);
    textAlign(CENTER);
    text("Upload a SEDAN, MINI VAN,", 155, 60);
    text(" or PICKUP TRUCK.", 155, 85);
    inputElement.position(60, 120);
  }
  function drawOutput(){
    fill(color(255, 255, 255, 70));
    var bg = rect(800, 20, 250, 130, 20);
    fill(255);
    textSize(18);
    textAlign(CENTER);
    calculateToll(label);

    text("Your vehicle: " + label, 920, 80);
    text("Toll: $" + toll, 920, 110);

    inputElement.position(60, 120);
  }
  function calculateToll(){
    if(label == "Sedan"){
      toll = 2.00
    }
    if(label == "Pickup Truck"){
      toll = 6.00
    }
    if(label == "Mini-Van"){
      toll = 4.00
    }
    
  }